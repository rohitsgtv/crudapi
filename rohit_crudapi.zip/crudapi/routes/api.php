<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\UserController;
use App\Http\Controllers\CrudapiController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::get('getdata/{id?}','App\Http\Controllers\CrudapiController@getdata');
Route::post('postdata','App\Http\Controllers\CrudapiController@postdata');
Route::post('updatedata','App\Http\Controllers\CrudapiController@updatedata');
Route::get('destroydata/{id}','App\Http\Controllers\CrudapiController@destroydata');
