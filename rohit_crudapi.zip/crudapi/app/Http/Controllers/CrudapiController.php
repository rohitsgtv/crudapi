<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Students;

class CrudapiController extends Controller
{
    public function getdata($id=null){
        return $id?Students::where('id',$id)->get():Students::all();
    }
    
    public function postdata(Request $request) {

        $student=Students::create([
            'name'=> $request->name,
            'rollnumber'=> $request->rollnumber,
        ]);
        if($student){ 
            return ["Result"=>"success"];
        }else{
            return ["Result"=>"failed"];
        }
       
    }
    
    public function updatedata(Request $request)
    {
        $student = Students::find($request->id);
        $student->update([
            'name'=> $request->name,
            'rollnumber'=> $request->rollnumber
                ]);
        if($student){ 
            return ["Result"=>"success"];
        }else{
            return ["Result"=>"failed"];
        }
    }
    public function destroydata($id)
    {
        $student = Students::destroy($id);
        if($student)
        {
        return ["Result"=>"success"];
        }
        else{
            return ["Result"=>"failed"];
        }
    }
}
